﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 
 * UI: UI/uiTemplate/Hall/HeadRank.ui
 * TIME: 2023.08.01-15.33.50
 */

 

 @UIBind('UI/uiTemplate/Hall/HeadRank.ui')
 export default class HeadRank_Generate extends mw.UIScript {
	 @UIWidgetBind('RootCanvas/mCanvas_Rank_1/mImg_BG_1')
    public mImg_BG_1: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_1/mText_Rank_1')
    public mText_Rank_1: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_1')
    public mCanvas_Rank_1: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_2/mImg_BG_2')
    public mImg_BG_2: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_2/mText_Rank_2')
    public mText_Rank_2: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_2')
    public mCanvas_Rank_2: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_3/mImg_BG_3')
    public mImg_BG_3: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_3/mText_Rank_3')
    public mText_Rank_3: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_3')
    public mCanvas_Rank_3: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_4/mImg_BG_4')
    public mImg_BG_4: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_4/mText_Rank_4')
    public mText_Rank_4: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_4')
    public mCanvas_Rank_4: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_5/mImg_BG_5')
    public mImg_BG_5: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_5/mText_Rank_5')
    public mText_Rank_5: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_5')
    public mCanvas_Rank_5: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_6/mImg_BG_6')
    public mImg_BG_6: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_6/mText_Rank_6')
    public mText_Rank_6: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_6')
    public mCanvas_Rank_6: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_7/mImg_BG_7')
    public mImg_BG_7: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_7/mText_Rank_7')
    public mText_Rank_7: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_7')
    public mCanvas_Rank_7: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_8/mImg_BG_8')
    public mImg_BG_8: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_8/mText_Rank_8')
    public mText_Rank_8: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_8')
    public mCanvas_Rank_8: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_9/mImg_BG_9')
    public mImg_BG_9: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_9/mText_Rank_9')
    public mText_Rank_9: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_9')
    public mCanvas_Rank_9: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_10/mImg_BG_10')
    public mImg_BG_10: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_10/mText_Rank_10')
    public mText_Rank_10: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_10')
    public mCanvas_Rank_10: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_11/mImg_BG_11')
    public mImg_BG_11: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_11/mText_Rank_11')
    public mText_Rank_11: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_11')
    public mCanvas_Rank_11: mw.Canvas=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_12/mImg_BG_12')
    public mImg_BG_12: mw.Image=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_12/mText_Rank_12')
    public mText_Rank_12: mw.TextBlock=undefined;
    @UIWidgetBind('RootCanvas/mCanvas_Rank_12')
    public mCanvas_Rank_12: mw.Canvas=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mText_Rank_1)
		
	
		this.initLanguage(this.mText_Rank_2)
		
	
		this.initLanguage(this.mText_Rank_3)
		
	
		this.initLanguage(this.mText_Rank_4)
		
	
		this.initLanguage(this.mText_Rank_5)
		
	
		this.initLanguage(this.mText_Rank_6)
		
	
		this.initLanguage(this.mText_Rank_7)
		
	
		this.initLanguage(this.mText_Rank_8)
		
	
		this.initLanguage(this.mText_Rank_9)
		
	
		this.initLanguage(this.mText_Rank_10)
		
	
		this.initLanguage(this.mText_Rank_11)
		
	
		this.initLanguage(this.mText_Rank_12)
		
	
		//文本多语言
		

	}
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 
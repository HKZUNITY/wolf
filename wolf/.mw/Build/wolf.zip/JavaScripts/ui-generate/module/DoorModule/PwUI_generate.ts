﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/DoorModule/PwUI.ui
 * TIME: 2024.11.09-23.55.57
 */
 
@UIBind('UI/module/DoorModule/PwUI.ui')
export default class PwUI_Generate extends UIScript {
		private mStaleButton_exit_Internal: mw.StaleButton
	public get mStaleButton_exit(): mw.StaleButton {
		if(!this.mStaleButton_exit_Internal&&this.uiWidgetBase) {
			this.mStaleButton_exit_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mStaleButton_exit') as mw.StaleButton
		}
		return this.mStaleButton_exit_Internal
	}
	private mImage_BackColor_Internal: mw.Image
	public get mImage_BackColor(): mw.Image {
		if(!this.mImage_BackColor_Internal&&this.uiWidgetBase) {
			this.mImage_BackColor_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mImage_BackColor') as mw.Image
		}
		return this.mImage_BackColor_Internal
	}
	private mButton_1_Internal: mw.StaleButton
	public get mButton_1(): mw.StaleButton {
		if(!this.mButton_1_Internal&&this.uiWidgetBase) {
			this.mButton_1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_1') as mw.StaleButton
		}
		return this.mButton_1_Internal
	}
	private mButton_2_Internal: mw.StaleButton
	public get mButton_2(): mw.StaleButton {
		if(!this.mButton_2_Internal&&this.uiWidgetBase) {
			this.mButton_2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_2') as mw.StaleButton
		}
		return this.mButton_2_Internal
	}
	private mButton_3_Internal: mw.StaleButton
	public get mButton_3(): mw.StaleButton {
		if(!this.mButton_3_Internal&&this.uiWidgetBase) {
			this.mButton_3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_3') as mw.StaleButton
		}
		return this.mButton_3_Internal
	}
	private mButton_0_Internal: mw.StaleButton
	public get mButton_0(): mw.StaleButton {
		if(!this.mButton_0_Internal&&this.uiWidgetBase) {
			this.mButton_0_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_0') as mw.StaleButton
		}
		return this.mButton_0_Internal
	}
	private mButton_4_Internal: mw.StaleButton
	public get mButton_4(): mw.StaleButton {
		if(!this.mButton_4_Internal&&this.uiWidgetBase) {
			this.mButton_4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_4') as mw.StaleButton
		}
		return this.mButton_4_Internal
	}
	private mButton_5_Internal: mw.StaleButton
	public get mButton_5(): mw.StaleButton {
		if(!this.mButton_5_Internal&&this.uiWidgetBase) {
			this.mButton_5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_5') as mw.StaleButton
		}
		return this.mButton_5_Internal
	}
	private mButton_6_Internal: mw.StaleButton
	public get mButton_6(): mw.StaleButton {
		if(!this.mButton_6_Internal&&this.uiWidgetBase) {
			this.mButton_6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_6') as mw.StaleButton
		}
		return this.mButton_6_Internal
	}
	private mButton_R_Internal: mw.StaleButton
	public get mButton_R(): mw.StaleButton {
		if(!this.mButton_R_Internal&&this.uiWidgetBase) {
			this.mButton_R_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_R') as mw.StaleButton
		}
		return this.mButton_R_Internal
	}
	private mButton_7_Internal: mw.StaleButton
	public get mButton_7(): mw.StaleButton {
		if(!this.mButton_7_Internal&&this.uiWidgetBase) {
			this.mButton_7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_7') as mw.StaleButton
		}
		return this.mButton_7_Internal
	}
	private mButton_8_Internal: mw.StaleButton
	public get mButton_8(): mw.StaleButton {
		if(!this.mButton_8_Internal&&this.uiWidgetBase) {
			this.mButton_8_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_8') as mw.StaleButton
		}
		return this.mButton_8_Internal
	}
	private mButton_9_Internal: mw.StaleButton
	public get mButton_9(): mw.StaleButton {
		if(!this.mButton_9_Internal&&this.uiWidgetBase) {
			this.mButton_9_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_9') as mw.StaleButton
		}
		return this.mButton_9_Internal
	}
	private mButton_OK_Internal: mw.StaleButton
	public get mButton_OK(): mw.StaleButton {
		if(!this.mButton_OK_Internal&&this.uiWidgetBase) {
			this.mButton_OK_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mButton_OK') as mw.StaleButton
		}
		return this.mButton_OK_Internal
	}
	private mTextBlock4_Internal: mw.TextBlock
	public get mTextBlock4(): mw.TextBlock {
		if(!this.mTextBlock4_Internal&&this.uiWidgetBase) {
			this.mTextBlock4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mCanvas_pw/mTextBlock4') as mw.TextBlock
		}
		return this.mTextBlock4_Internal
	}
	private mTextBlock_1_Internal: mw.TextBlock
	public get mTextBlock_1(): mw.TextBlock {
		if(!this.mTextBlock_1_Internal&&this.uiWidgetBase) {
			this.mTextBlock_1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mCanvas_pw/mTextBlock_1') as mw.TextBlock
		}
		return this.mTextBlock_1_Internal
	}
	private mTextBlock_3_Internal: mw.TextBlock
	public get mTextBlock_3(): mw.TextBlock {
		if(!this.mTextBlock_3_Internal&&this.uiWidgetBase) {
			this.mTextBlock_3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mCanvas_pw/mTextBlock_3') as mw.TextBlock
		}
		return this.mTextBlock_3_Internal
	}
	private mTextBlock_2_Internal: mw.TextBlock
	public get mTextBlock_2(): mw.TextBlock {
		if(!this.mTextBlock_2_Internal&&this.uiWidgetBase) {
			this.mTextBlock_2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mCanvas_pw/mTextBlock_2') as mw.TextBlock
		}
		return this.mTextBlock_2_Internal
	}
	private mCanvas_pw_Internal: mw.Canvas
	public get mCanvas_pw(): mw.Canvas {
		if(!this.mCanvas_pw_Internal&&this.uiWidgetBase) {
			this.mCanvas_pw_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey/mCanvas_pw') as mw.Canvas
		}
		return this.mCanvas_pw_Internal
	}
	private mKey_Internal: mw.Canvas
	public get mKey(): mw.Canvas {
		if(!this.mKey_Internal&&this.uiWidgetBase) {
			this.mKey_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/mKey') as mw.Canvas
		}
		return this.mKey_Internal
	}


	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mStaleButton_exit.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mStaleButton_exit");
		});
		this.initLanguage(this.mStaleButton_exit);
		this.mStaleButton_exit.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_1.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_1");
		});
		this.initLanguage(this.mButton_1);
		this.mButton_1.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_2.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_2");
		});
		this.initLanguage(this.mButton_2);
		this.mButton_2.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_3.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_3");
		});
		this.initLanguage(this.mButton_3);
		this.mButton_3.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_0.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_0");
		});
		this.initLanguage(this.mButton_0);
		this.mButton_0.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_4.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_4");
		});
		this.initLanguage(this.mButton_4);
		this.mButton_4.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_5.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_5");
		});
		this.initLanguage(this.mButton_5);
		this.mButton_5.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_6.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_6");
		});
		this.initLanguage(this.mButton_6);
		this.mButton_6.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_R.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_R");
		});
		this.initLanguage(this.mButton_R);
		this.mButton_R.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_7.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_7");
		});
		this.initLanguage(this.mButton_7);
		this.mButton_7.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_8.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_8");
		});
		this.initLanguage(this.mButton_8);
		this.mButton_8.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_9.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_9");
		});
		this.initLanguage(this.mButton_9);
		this.mButton_9.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		this.mButton_OK.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mButton_OK");
		});
		this.initLanguage(this.mButton_OK);
		this.mButton_OK.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mTextBlock4)
		
	
		this.initLanguage(this.mTextBlock_1)
		
	
		this.initLanguage(this.mTextBlock_3)
		
	
		this.initLanguage(this.mTextBlock_2)
		
	
		//文本多语言
		
	}
	
	/*初始化多语言*/
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		mw.UIService.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		mw.UIService.hideUI(this);
	}
 }
 
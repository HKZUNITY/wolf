// /*
//  * @Autor:
//  * @Date: 2022-03-23 10:26:35
//  * @Description:
//  * @LastEditors: Please set LastEditors
//  * @LastEditTime: 2022-03-30 18:26:20
//  * @FilePath: \JavaScripts\GameAssets.ts
//  */
// //动作资源枚举
// export enum ResType_Animation {
//     // Skill1 = '20243',
//     // Skill2 = '20249',
//     // Skill3 = '20269',
//     // Skill4 = '21615',
//     // Skill5 = '20246',
//     // Skill6 = '20270',
// }
// //声音资源枚举
// export enum ResType_Sound {
//     // Button = "7990",
//     //增加声音往下写...
// }
// //特效资源的枚举
// export enum ResType_Effect {
//     // BulletEffect1 = "3CCEBB02468D60E0FAC9B8B8D2E7DC9D",
//     // GunEffect1 = "2543D16C44CBE62C117C148AC300F754",
//     // HitEffect = "2543D16C44CBE62C117C148AC300F754",
//     // KnifeEffect = "BB2A2ABB440012B2E8F8368EFE933117",
//     //GunLeaveEffect = "68B156D64F3137D2C07D839801195F2D"
//     // HitFlash    = "544D22E741815716F9BF20942FA5AA89",
//     // KnifeFlash  = "4DD1E2654E2AF9CA100BA8B28E7B586F",
//     // Skill3_1    = "D10D1C9048033C48063214A079E0B786",
//     // Skill3_2    = "502FDBD74F8073D86F6B0D943C4B7B78",
//     // Skill3_3    = "0D9E1C3E4D044F10498CD58289E7E028",
//     // Skill6_1    = "15DDF5C740D3B9C0D491608FE467AF59"
//     //增加的特效往下写...
// }
// //特效资源的时间长度
// //这个时间决定特效播放后多久被回收，现在编辑器无法判断特效播放时间，只能手动填写，以后要废弃掉的。
// //可以不写，默认3秒
// export class EffectTime {
//     // static Food_Quan = 5;
//     //增加的特效往下写...
// }